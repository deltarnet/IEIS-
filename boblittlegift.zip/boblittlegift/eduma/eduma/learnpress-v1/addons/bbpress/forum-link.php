<div class="forum-link">
	<label><?php esc_html_e( 'Connect', 'eduma' ); ?></label>
	<div class="value">
		<a href="<?php echo get_the_permalink(); ?>"><?php esc_html_e( 'Forum', 'eduma' ); ?></a>
	</div>
</div>